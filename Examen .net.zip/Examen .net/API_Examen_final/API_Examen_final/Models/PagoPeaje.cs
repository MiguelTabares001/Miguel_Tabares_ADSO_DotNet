﻿using System;
using System.ComponentModel.DataAnnotations;

namespace API_Examen_final.Models
{
    public class PagoPeaje
    {
        public int Id { get; set; }

        [Required]
        public string? Placa { get; set; }

        [Required]
        public string? NombrePeaje { get; set; }

        [Required]
        [RegularExpression(@"^(I|II|III|IV|V)$", ErrorMessage = "La categoría de tarifa debe ser I, II, III, IV o V")]
        public string? IdCategoriaTarifa { get; set; }

        [Required]
        public DateTime FechaRegistro { get; set; }

        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "El valor debe ser mayor o igual a 0")]
        public decimal Valor { get; set; }
    }
}
