document.addEventListener("DOMContentLoaded", async function() {
    const apiUrl = "http://tabaresmiguelxd3-001-site1.jtempurl.com/api/pagoPeaje";
    const tableBody = document.querySelector("#peaje-table tbody");
    const modal = document.getElementById("modal");
    const modalTitle = document.getElementById("modal-title");
    const form = document.getElementById("form");
    const closeModalButton = document.querySelector(".close");

    const inputs = {
        id: document.getElementById("id"),
        placa: document.getElementById("placa"),
        nombrePeaje: document.getElementById("nombrePeaje"),
        idCategoriaTarifa: document.getElementById("idCategoriaTarifa"),
        fechaRegistro: document.getElementById("fechaRegistro"),
        valor: document.getElementById("valor"),
    };

    // Cargar nombres de peajes y categorías tarifa al cargar la página
    const peajes = await fetchPeajes();
    populateNombrePeajeDropdown(peajes);
    populateIdCategoriaTarifaDropdown();

    document.getElementById("add-button").onclick = function() {
        openModal();
    };

    closeModalButton.onclick = function() {
        closeModal();
    };

    window.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };

    form.onsubmit = function(event) {
        event.preventDefault();
        const method = inputs.id.value ? 'PUT' : 'POST';
        const url = inputs.id.value ? `${apiUrl}/${inputs.id.value}` : apiUrl;

        const data = {
            id: inputs.id.value || undefined,
            placa: inputs.placa.value,
            nombrePeaje: inputs.nombrePeaje.value,
            idCategoriaTarifa: inputs.idCategoriaTarifa.value,
            fechaRegistro: new Date(inputs.fechaRegistro.value).toISOString(),
            valor: parseFloat(inputs.valor.value)
        };

        fetch(url, {
            method: method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(err => { throw err; });
            }
            return response.json();
        })
        .then(data => {
            closeModal();
            fetchData(); // Actualizar la tabla después de guardar o editar
        })
        .catch(error => {
            console.error("Error:", error);
            if (error.errors) {
                for (const [field, messages] of Object.entries(error.errors)) {
                    console.error(`Error en el campo ${field}: ${messages.join(', ')}`);
                }
            } else {
                console.error("Otro tipo de error:", error.message);
            }
        });
    };

    function openModal(data = {}) {
        modal.style.display = "block";
        modalTitle.textContent = data.id ? "Editar Pago Peaje" : "Agregar Pago Peaje";
        inputs.id.value = data.id || '';
        inputs.placa.value = data.placa || '';
        inputs.nombrePeaje.value = data.nombrePeaje || '';
        inputs.idCategoriaTarifa.value = data.idCategoriaTarifa || 'I';
        inputs.fechaRegistro.value = data.fechaRegistro ? new Date(data.fechaRegistro).toISOString().substring(0, 16) : '';
        inputs.valor.value = data.valor || '';

        // Autocompletar el valor al cambiar nombrePeaje o idCategoriaTarifa
        inputs.nombrePeaje.addEventListener("change", autocompleteValor);
        inputs.idCategoriaTarifa.addEventListener("change", autocompleteValor);
    }

    function closeModal() {
        modal.style.display = "none";
        form.reset();
        inputs.nombrePeaje.removeEventListener("change", autocompleteValor);
        inputs.idCategoriaTarifa.removeEventListener("change", autocompleteValor);
    }

    function fetchData() {
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                tableBody.innerHTML = '';
                data.forEach(pagoPeaje => {
                    const row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${pagoPeaje.id}</td>
                        <td>${pagoPeaje.placa}</td>
                        <td>${pagoPeaje.nombrePeaje}</td>
                        <td>${pagoPeaje.idCategoriaTarifa}</td>
                        <td>${new Date(pagoPeaje.fechaRegistro).toLocaleString()}</td>
                        <td>${pagoPeaje.valor}</td>
                        <td>
                            <button onclick='editPagoPeaje(${JSON.stringify(pagoPeaje)})'>Editar</button>
                            <button onclick='deletePagoPeaje(${pagoPeaje.id})'>Eliminar</button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            })
            .catch(error => console.error("Error fetching data:", error));
    }

    function populateNombrePeajeDropdown(peajes) {
        const dropdown = document.getElementById("nombrePeaje");
        dropdown.innerHTML = '';
        
        // Utilizar un Set para asegurarse de que los nombres de peajes sean únicos
        const uniquePeajes = new Set(peajes.map(peaje => peaje.peaje));
        
        uniquePeajes.forEach(nombre => {
            const option = document.createElement("option");
            option.value = nombre;
            option.textContent = nombre;
            dropdown.appendChild(option);
        });
    }

    function populateIdCategoriaTarifaDropdown() {
        const dropdown = document.getElementById("idCategoriaTarifa");
        dropdown.innerHTML = '';
        ['I', 'II', 'III', 'IV', 'V'].forEach(categoria => {
            const option = document.createElement("option");
            option.value = categoria;
            option.textContent = categoria;
            dropdown.appendChild(option);
        });
    }

    async function autocompleteValor() {
        const selectedNombrePeaje = inputs.nombrePeaje.value;
        const selectedCategoriaTarifa = inputs.idCategoriaTarifa.value;

        try {
            const response = await fetch('https://www.datos.gov.co/resource/7gj8-j6i3.json');
            if (!response.ok) {
                throw new Error('Error al obtener datos de peajes');
            }
            const peajes = await response.json();

            const peaje = peajes.find(p => p.peaje === selectedNombrePeaje && p.idcategoriatarifa === selectedCategoriaTarifa);
            if (peaje) {
                inputs.valor.value = peaje.valor;
            } else {
                console.error(`No se encontró el peaje con nombre '${selectedNombrePeaje}' y categoría tarifa '${selectedCategoriaTarifa}'`);
            }
        } catch (error) {
            console.error('Error fetching peajes:', error);
        }
    }

    async function fetchPeajes() {
        try {
            const response = await fetch('https://www.datos.gov.co/resource/7gj8-j6i3.json');
            if (!response.ok) {
                throw new Error('Error al obtener datos de peajes');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching peajes:', error);
            return [];
        }
    }

    // Exponer funciones al ámbito global
    window.editPagoPeaje = function(pagoPeaje) {
        openModal(pagoPeaje);
    };

    window.deletePagoPeaje = function(id) {
        fetch(`${apiUrl}/${id}`, { method: 'DELETE' })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw err; });
                }
                fetchData(); // Actualizar la tabla después de eliminar
            })
            .catch(error => console.error('Error deleting data:', error));
    };

    // Cargar datos iniciales
    fetchData();
});
