﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_Examen_final.Migrations
{
    /// <inheritdoc />
    public partial class migracionlocal : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
