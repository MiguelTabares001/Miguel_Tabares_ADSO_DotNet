﻿global using System.ComponentModel.DataAnnotations;
global using Microsoft.EntityFrameworkCore;
global using API_Examen_final.Models;
global using API_Examen_final.Controllers;
