﻿using API_pedidos.Data;
using Microsoft.AspNetCore.Mvc;

namespace API_Examen_final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PagoPeajeController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public PagoPeajeController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PagoPeaje>>>
        GetPagoPeaje()
        {
            return await _context.PagoPeajes.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<PagoPeaje>> GetPagoPeaje(int id)
        {
            var pagoPeaje = await _context.PagoPeajes.FindAsync(id);
            if (pagoPeaje == null)
            {
                return NotFound();
            }
            return pagoPeaje;
        }
        [HttpPost]
        public async Task<ActionResult<PagoPeaje>>
        PostCSharpCornerArticle(PagoPeaje pagoPeaje)
        {
            _context.PagoPeajes.Add(pagoPeaje);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetPagoPeaje", new
            {
                id =
            pagoPeaje.Id
            }, pagoPeaje);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPagoPeaje(int id, PagoPeaje
        pagoPeaje)
        {
            if (id != pagoPeaje.Id)
            {
                return BadRequest();
            }
            _context.Entry(pagoPeaje).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PagoPeajeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePagoPeaje(int id)
        {
            var pagoPeaje = await _context.PagoPeajes.FindAsync(id);
            if (pagoPeaje == null)
            {
                return NotFound();
            }
            _context.PagoPeajes.Remove(pagoPeaje);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        private bool PagoPeajeExists(int id)
        {
            return _context.PagoPeajes.Any(e => e.Id == id);
        }
    }
}
